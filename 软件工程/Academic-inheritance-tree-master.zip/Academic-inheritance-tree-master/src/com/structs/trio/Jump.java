package com.structs.trio;

public class Jump 
{
	public String returnHome() {
		return "SUCCESS";
	}
	
	public String returninfo() {
		return "SUCCESS";
	}
	
	public String returninfoOther() {
		return "SUCCESS";
	}
}
